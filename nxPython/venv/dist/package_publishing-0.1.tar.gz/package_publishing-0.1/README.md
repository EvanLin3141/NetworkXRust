# Testing my package

## Installation

```bash
pip install nxPython